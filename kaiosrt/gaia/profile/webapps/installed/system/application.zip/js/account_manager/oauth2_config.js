const Oauth2Config = {
  google: {
    scope:
      'https://www.googleapis.com/auth/userinfo.email https://www.googleapis.com/auth/contacts https://www.googleapis.com/auth/calendar https://mail.google.com/ https://www.google.com/m8/feeds/',
    client_id:
      '100183967378-i5vsj453tr6e6od88p6ijrtjqf8lakfe.apps.googleusercontent.com',
    token_uri: 'https://www.googleapis.com/oauth2/v4/token',
    auth_uri: 'https://accounts.google.com/o/oauth2/v2/auth',
    revoke_uri: 'https://accounts.google.com/o/oauth2/revoke',
    client_secret: '1W3lY6OrHRg-AsytPtY3up6g',
    redirect_uri: 'http://localhost/redirect/loginpages/redirect.html',
  },
};

window.Oauth2Config = Oauth2Config;
